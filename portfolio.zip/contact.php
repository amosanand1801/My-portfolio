<?php
// Connect to database
$db = new SQLite3('contact.db');

// Check form submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Get form data
    $username = htmlspecialchars($_POST['username']);
    $email = htmlspecialchars($_POST['email']);
    $msg = htmlspecialchars($_POST['msg']);

    // Insert data
    $stmt = $db->prepare("INSERT INTO contact_form (username, email, message) VALUES (:username, :email, :msg)");
    $stmt->bindValue(':username', $username, SQLITE3_TEXT);
    $stmt->bindValue(':email', $email, SQLITE3_TEXT);
    $stmt->bindValue(':msg', $msg, SQLITE3_TEXT);

    if ($stmt->execute()) {
        echo "<script>alert('Message submitted successfully!');window.location.href='index.html';</script>";
    } else {
        echo "<script>alert('Message submitted unsuccessful!');window.location.href='index.html';</script>";
    }
}
?>